import { useState } from 'react';
import { 
  LayoutDashboard, 
  Building2, 
  Layers, 
  Users, 
  Stethoscope, 
  FileText, 
  Search, 
  Filter, 
  Download, 
  Plus, 
  Check,
  Pencil, 
  Eye, 
  Trash2, 
  HelpCircle,
  ChevronLeft,
  ChevronRight,
  MoreVertical
} from 'lucide-react';

export default function App() {
  const [activeDropdown, setActiveDropdown] = useState<number | null>(null);
  const [view, setView] = useState<'list' | 'add'>('list');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedTierIndex, setSelectedTierIndex] = useState<number | null>(null);
  const [newTierModules, setNewTierModules] = useState<string[]>([]);
  const [newTier, setNewTier] = useState({ name: '', subName: '', description: '', years: 5, months: 0 });
  const [editingModules, setEditingModules] = useState<string[]>([]);
  const [editingTier, setEditingTier] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const [tiers, setTiers] = useState([
    {
      name: "Clinical Basic",
      subName: "Diagnostic Tier",
      description: "Essential analytics for small clinics focusing on patient demographics and basic diagnostic trends.",
      modules: ["PATIENT_DEMOGRAPHICS", "DIAGNOSTIC_TRENDS"],
      color: "border-blue-400",
      years: 1,
      months: 0
    },
    {
      name: "Operational Pro",
      subName: "Facility Management",
      description: "Comprehensive operational insights including staff allocation, resource utilization, and patient flow analytics.",
      modules: ["RESOURCE_PLANNING", "STAFF_ANALYTICS", "PATIENT_FLOW", "INVENTORY_TRACKING"],
      color: "border-teal-400",
      years: 3,
      months: 0
    },
    {
      name: "Financial Elite",
      subName: "Revenue Cycle",
      description: "Advanced financial analytics for hospital networks, covering billing efficiency, insurance claim trends, and revenue forecasting.",
      modules: ["BILLING_INSIGHTS", "CLAIMS_ANALYSIS", "REVENUE_FORECASTING", "COST_OPTIMIZATION", "FINANCIAL_REPORTING"],
      color: "border-emerald-600",
      years: 5,
      months: 0
    },
    {
      name: "Enterprise Health",
      subName: "Network Intelligence",
      description: "Full-scale network intelligence for hospital groups with multi-facility benchmarking and population health management.",
      modules: ["NETWORK_BENCHMARKING", "POPULATION_HEALTH", "PREDICTIVE_OUTCOMES", "COMPLIANCE_MONITORING", "STRATEGIC_PLANNING", "QUALITY_METRICS"],
      color: "border-cyan-500",
      years: 10,
      months: 0
    },
    {
      name: "Research & Innovation",
      subName: "Advanced R&D",
      description: "Bespoke analytics solutions for research-heavy institutions with deep-dive clinical data mining and AI-driven insights.",
      modules: ["CLINICAL_DATA_MINING", "AI_INSIGHTS", "RESEARCH_DASHBOARD", "GENOMIC_TRENDS", "TRIAL_ANALYTICS", "CUSTOM_MODELS", "DATA_EXPORT_API"],
      color: "border-orange-400",
      years: 99,
      months: 0
    }
  ]);

  const sidebarItems = [
    { icon: LayoutDashboard, label: "Analytics Dashboard" },
    { icon: Building2, label: "Hospitals" },
    { icon: Layers, label: "Tier Management", active: true },
    { icon: Users, label: "Staff Directory" },
    { icon: Stethoscope, label: "Clinical Insights" },
    { icon: FileText, label: "Financial Reports" },
  ];

  const toggleDropdown = (index: number) => {
    setActiveDropdown(activeDropdown === index ? null : index);
  };

  const handleSaveTier = () => {
    if (!newTier.name || !newTier.subName) return;
    
    const tierToAdd = {
      ...newTier,
      modules: newTierModules,
      color: "border-slate-400"
    };
    setTiers([...tiers, tierToAdd]);
    setNewTier({ name: '', subName: '', description: '', years: 5, months: 0 });
    setNewTierModules([]);
    setShowConfirmModal(false);
    setShowSuccessModal(true);
  };

  const handleDeactivateTier = (index: number) => {
    const updatedTiers = tiers.filter((_, i) => i !== index);
    setTiers(updatedTiers);
    setActiveDropdown(null);
  };

  const handleSuccessClose = () => {
    setShowSuccessModal(false);
    setView('list');
  };

  return (
    <div className="flex h-screen bg-[#F8FAFB] font-sans text-slate-800">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6 flex items-center gap-3">
          <div className="w-8 h-8 bg-[#009688] rounded-lg flex items-center justify-center text-white">
            <Layers size={20} />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">Stash Admin</h1>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Management Portal</p>
          </div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1">
          {sidebarItems.map((item, index) => (
            <button
              key={index}
              onClick={() => item.label === "Tier Management" && setView('list')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                item.active 
                  ? "bg-[#E0F2F1] text-[#00796B] border-r-4 border-[#00796B] rounded-r-none" 
                  : "text-slate-500 hover:bg-slate-50"
              }`}
            >
              <item.icon size={18} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className="bg-slate-50 rounded-xl p-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden">
              <img 
                src="https://picsum.photos/seed/admin/100/100" 
                alt="Admin" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <p className="text-sm font-bold">Admin User</p>
              <p className="text-[10px] text-slate-400 font-semibold">Super Admin</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Home</span>
            <span>/</span>
            <span className="text-slate-400">Tier Management</span>
            {view === 'add' && (
              <>
                <span>/</span>
                <span className="text-[#009688] font-medium">Add Tier</span>
              </>
            )}
            {view === 'list' && (
              <span className="hidden">/</span>
            )}
            {view === 'list' && (
              <span className="text-[#009688] font-medium ml-[-8px]"></span>
            )}
          </div>
          <div className="flex items-center gap-6">
            <div className="text-[10px] text-emerald-500 font-medium flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
              Data Analytics Engine is operational.
            </div>
            <div className="flex items-center gap-2 text-sm font-medium text-slate-600 cursor-pointer hover:text-slate-900">
              <div className="w-8 h-8 bg-[#009688] rounded-lg flex items-center justify-center text-white">
                <Users size={16} />
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8" onClick={() => setActiveDropdown(null)}>
          <div className="w-full">
            {view === 'list' ? (
              <>
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h2 className="text-3xl font-bold mb-2">Hospital Analytics Tiers</h2>
                    <p className="text-slate-500 text-sm max-w-xl">
                      Configure and manage analytics service levels for hospital facilities. 
                      Define data insights, module access, and operational limits per tier.
                    </p>
                  </div>
                  <button 
                    onClick={() => setView('add')}
                    className="bg-[#009688] hover:bg-[#00796B] text-white px-6 py-2.5 rounded-lg font-bold text-sm flex items-center gap-2 transition-colors shadow-sm"
                  >
                    <Plus size={18} />
                    Add New Tier
                  </button>
                </div>

                {/* Filters */}
                <div className="flex items-center justify-between gap-4 mb-6">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="text" 
                      placeholder="Search tiers by name or module..." 
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-slate-100 border-none rounded-lg pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-[#009688] transition-all"
                    />
                  </div>
                  <div className="flex items-center gap-4">
                    <button className="bg-white border border-slate-200 text-slate-600 px-4 py-2.5 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-slate-50">
                      <Filter size={16} />
                      Filter
                    </button>
                    <button className="bg-white border border-slate-200 text-slate-600 px-4 py-2.5 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-slate-50">
                      <Download size={16} />
                      Export
                    </button>
                  </div>
                </div>

                {/* Table */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200">
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider rounded-tl-xl w-[20%]">Tier Name</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider w-[25%]">Description</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider w-[30%]">
                          <div className="flex items-center gap-2">
                            Modules
                            <span className="bg-slate-200 text-slate-500 px-1.5 py-0.5 rounded text-[8px] font-bold">Qty</span>
                          </div>
                        </th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider w-[15%]">Data Limit</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-right rounded-tr-xl w-[10%]">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {tiers.filter(tier => 
                        tier.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                        tier.modules.some(m => m.toLowerCase().includes(searchQuery.toLowerCase())) ||
                        tier.subName.toLowerCase().includes(searchQuery.toLowerCase())
                      ).length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-12 text-center">
                            <div className="flex flex-col items-center gap-3 text-slate-400">
                              <Search size={40} strokeWidth={1} />
                              <p className="text-sm font-medium">No tiers found matching "{searchQuery}"</p>
                              <button 
                                onClick={() => setSearchQuery('')}
                                className="text-[#009688] text-xs font-bold hover:underline"
                              >
                                Clear search
                              </button>
                            </div>
                          </td>
                        </tr>
                      ) : (
                        tiers.map((tier, index) => {
                          const matchesSearch = tier.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                                              tier.modules.some(m => m.toLowerCase().includes(searchQuery.toLowerCase())) ||
                                              tier.subName.toLowerCase().includes(searchQuery.toLowerCase());
                          
                          if (!matchesSearch) return null;

                          return (
                            <tr key={index} className={`group hover:bg-slate-50 transition-colors ${activeDropdown === index ? 'bg-[#F0F9F8]' : ''}`}>
                              <td className="px-6 py-5">
                                <div className={`pl-3 border-l-4 ${tier.color}`}>
                                  <p className="font-bold text-sm">{tier.name}</p>
                                  <p className="text-[10px] text-[#009688] font-bold uppercase tracking-tight">{tier.subName}</p>
                                </div>
                              </td>
                              <td className="px-6 py-5">
                                <p className="text-slate-500 text-xs leading-relaxed" title={tier.description}>
                                  {tier.description}
                                </p>
                              </td>
                              <td className="px-6 py-5">
                                <div className="flex items-center gap-2 mb-3">
                                  <span className="bg-[#E0F2F1] text-[#00796B] text-[9px] font-bold px-2 py-0.5 rounded-full border border-[#B2E8D9] flex items-center gap-1">
                                    <div className="w-1 h-1 bg-[#009688] rounded-full"></div>
                                    {tier.modules.length} {tier.modules.length === 1 ? 'Module' : 'Modules'}
                                  </span>
                                </div>
                                <div className="flex flex-wrap gap-1.5">
                                  {tier.modules.map((mod, modIdx) => (
                                    <span 
                                      key={modIdx} 
                                      className="bg-[#B2E8D9] text-[#2D5A50] text-[9px] font-bold px-2 py-1 rounded uppercase tracking-wider"
                                    >
                                      {mod}
                                    </span>
                                  ))}
                                </div>
                              </td>
                              <td className="px-6 py-5">
                                <div className="flex items-center gap-2">
                                  <div className="flex flex-col">
                                    <span className="text-xs font-bold text-slate-700">{tier.years} <span className="text-[10px] text-slate-400 uppercase">Years</span></span>
                                    <span className="text-[10px] font-bold text-slate-400 uppercase">{tier.months} Months</span>
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-5 text-right relative">
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    toggleDropdown(index);
                                  }}
                                  className={`p-2 rounded-lg transition-colors ${activeDropdown === index ? 'bg-[#009688] text-white' : 'text-slate-400 hover:bg-slate-100'}`}
                                >
                                  <MoreVertical size={16} />
                                </button>
                                
                                {activeDropdown === index && (
                                  <div 
                                    className="absolute right-6 top-12 z-20 w-48 bg-white rounded-xl shadow-xl border border-slate-100 py-2 text-left animate-in fade-in slide-in-from-top-2 duration-200"
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    <button 
                                      onClick={() => {
                                        setSelectedTierIndex(index);
                                        setShowViewModal(true);
                                        setActiveDropdown(null);
                                      }}
                                      className="w-full px-4 py-2 text-xs font-medium text-slate-600 hover:bg-[#E0F2F1] flex items-center gap-3 transition-colors"
                                    >
                                      <Eye size={14} />
                                      View Tier
                                    </button>
                                    <button 
                                      onClick={() => {
                                        setSelectedTierIndex(index);
                                        setEditingTier({...tiers[index]});
                                        setEditingModules(tiers[index].modules);
                                        setShowEditModal(true);
                                        setActiveDropdown(null);
                                      }}
                                      className="w-full px-4 py-2 text-xs font-medium text-slate-600 hover:bg-[#E0F2F1] flex items-center gap-3 transition-colors"
                                    >
                                      <Pencil size={14} />
                                      Edit Tier
                                    </button>
                                    <div className="h-px bg-slate-100 my-1" />
                                    <button 
                                      onClick={() => handleDeactivateTier(index)}
                                      className="w-full px-4 py-2 text-xs font-medium text-red-500 hover:bg-red-50 flex items-center gap-3 transition-colors"
                                    >
                                      <Trash2 size={14} />
                                      Deactivate
                                    </button>
                                  </div>
                                )}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                  <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between rounded-b-xl">
                    <p className="text-xs text-slate-400 font-medium">
                      Showing <span className="text-slate-600">{
                        tiers.filter(tier => 
                          tier.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          tier.modules.some(m => m.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          tier.subName.toLowerCase().includes(searchQuery.toLowerCase())
                        ).length
                      }</span> of <span className="text-slate-600">{tiers.length}</span> tiers
                    </p>
                    <div className="flex items-center gap-2">
                      <button className="p-1 text-slate-300 cursor-not-allowed">
                        <ChevronLeft size={18} />
                      </button>
                      <button className="w-8 h-8 bg-[#009688] text-white rounded-lg text-xs font-bold">1</button>
                      <button className="p-1 text-slate-300 cursor-not-allowed">
                        <ChevronRight size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
                <h2 className="text-3xl font-bold mb-8">Add Tier</h2>
                
                <div className="bg-white rounded-2xl border border-slate-200 p-10 shadow-sm">
                  <div className="space-y-8 max-w-5xl">
                    {/* Tier Name & Sub-Name */}
                    <div className="grid grid-cols-2 gap-6 max-w-2xl">
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Tier Name</label>
                        <input 
                          type="text" 
                          placeholder="Enter tier name" 
                          value={newTier.name}
                          onChange={(e) => setNewTier({...newTier, name: e.target.value})}
                          className="w-full border border-slate-200 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-[#009688] focus:border-transparent outline-none transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Sub-Name / Label</label>
                        <input 
                          type="text" 
                          placeholder="e.g. Free Tier, Standard, etc." 
                          value={newTier.subName}
                          onChange={(e) => setNewTier({...newTier, subName: e.target.value})}
                          className="w-full border border-slate-200 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-[#009688] focus:border-transparent outline-none transition-all"
                        />
                      </div>
                    </div>

                    {/* Description */}
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Description</label>
                      <input 
                        type="text" 
                        placeholder="Short description for this tier" 
                        value={newTier.description}
                        onChange={(e) => setNewTier({...newTier, description: e.target.value})}
                        className="w-full border border-slate-200 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-[#009688] focus:border-transparent outline-none transition-all"
                      />
                    </div>

                    {/* Modules Covered */}
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">Modules Covered</label>
                      <div className="grid grid-cols-3 gap-4">
                        {["Demographics", "Diagnostics", "Resource Planning", "Staff Analytics", "Patient Flow", "Inventory", "Billing", "Claims", "Forecasting", "Compliance", "Quality Metrics", "AI Insights"].map((module) => {
                          const isSelected = newTierModules.includes(module.toUpperCase());
                          return (
                            <label 
                              key={module} 
                              className={`flex items-center gap-3 p-3 rounded-xl border transition-all cursor-pointer group ${
                                isSelected 
                                  ? "bg-[#E0F2F1] border-[#B2E8D9]" 
                                  : "bg-slate-50 border-slate-100 hover:bg-slate-100"
                              }`}
                            >
                              <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${
                                isSelected ? "bg-[#009688] border-[#009688]" : "bg-white border-slate-300"
                              }`}>
                                {isSelected && <Check size={12} className="text-white" strokeWidth={3} />}
                              </div>
                              <input 
                                type="checkbox" 
                                className="hidden"
                                checked={isSelected}
                                onChange={() => {
                                  const modUpper = module.toUpperCase();
                                  setNewTierModules(prev => 
                                    prev.includes(modUpper) 
                                      ? prev.filter(m => m !== modUpper) 
                                      : [...prev, modUpper]
                                  );
                                }}
                              />
                              <span className={`text-xs font-bold transition-colors ${
                                isSelected ? "text-[#00796B]" : "text-slate-600"
                              }`}>
                                {module}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* Data Limit */}
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">Data Limit</label>
                      <div className="flex gap-6">
                        <div className="flex-1 max-w-[200px]">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Years</label>
                          <input 
                            type="number" 
                            value={newTier.years}
                            onChange={(e) => setNewTier({...newTier, years: parseInt(e.target.value) || 0})}
                            className="w-full border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#009688] outline-none transition-all"
                          />
                        </div>
                        <div className="flex-1 max-w-[200px]">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Months</label>
                          <input 
                            type="number" 
                            value={newTier.months}
                            onChange={(e) => setNewTier({...newTier, months: parseInt(e.target.value) || 0})}
                            className="w-full border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#009688] outline-none transition-all"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-8 flex justify-center gap-4 border-t border-slate-100 mt-8">
                    <button 
                      onClick={() => setView('list')}
                      className="px-8 py-2.5 border border-slate-200 rounded-lg text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={() => setShowConfirmModal(true)}
                      className="px-8 py-2.5 bg-[#009688] hover:bg-[#00796B] text-white rounded-lg text-sm font-bold shadow-md transition-colors"
                    >
                      Save Tier Configuration
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-center text-orange-400 mb-6 mx-auto">
              <HelpCircle size={48} strokeWidth={1.5} />
            </div>
            <h3 className="text-xl font-bold text-center mb-2">Save Tier Configuration?</h3>
            <p className="text-slate-500 text-center text-sm mb-8">
              Are you sure you want to save this new tier configuration? This will be applied to all establishments under this tier.
            </p>
            <div className="flex gap-4">
              <button 
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 py-3 border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors"
              >
                No, Go Back
              </button>
              <button 
                onClick={handleSaveTier}
                className="flex-1 py-3 bg-[#009688] hover:bg-[#00796B] text-white rounded-xl text-sm font-bold shadow-md transition-colors"
              >
                Yes, Save Tier
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-center text-emerald-400 mb-6 mx-auto">
              <Check size={48} strokeWidth={2} />
            </div>
            <h3 className="text-xl font-bold text-center mb-2">Tier Saved Successfully!</h3>
            <p className="text-slate-500 text-center text-sm mb-8">
              The new tier has been successfully created and added to the management portal.
            </p>
            <button 
              onClick={handleSuccessClose}
              className="w-full py-3 bg-[#009688] hover:bg-[#00796B] text-white rounded-xl text-sm font-bold shadow-md transition-colors"
            >
              Back to Tier Management
            </button>
          </div>
        </div>
      )}

      {/* View Tier Modal */}
      {showViewModal && selectedTierIndex !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl p-8 max-w-2xl w-full shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden">
            <div className="flex justify-between items-start mb-6">
              <div className={`pl-4 border-l-4 ${tiers[selectedTierIndex].color}`}>
                <h3 className="text-2xl font-bold">{tiers[selectedTierIndex].name}</h3>
                <p className="text-xs text-[#009688] font-bold uppercase tracking-wider">{tiers[selectedTierIndex].subName}</p>
              </div>
              <button 
                onClick={() => setShowViewModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-colors"
              >
                <Plus className="rotate-45" size={20} />
              </button>
            </div>
            
            <div className="space-y-6">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Description</label>
                <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100 italic">
                  "{tiers[selectedTierIndex].description}"
                </p>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Enabled Modules</label>
                <div className="grid grid-cols-3 gap-3">
                  {tiers[selectedTierIndex].modules.map((mod, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-[#E0F2F1] px-3 py-2 rounded-lg border border-[#B2E8D9]">
                      <Check size={14} className="text-[#009688]" />
                      <span className="text-[10px] font-bold text-[#00796B] uppercase tracking-wider">{mod}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6 pt-4 border-t border-slate-100">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Data Retention</label>
                  <p className="text-lg font-bold text-slate-700">{tiers[selectedTierIndex].years} Years, {tiers[selectedTierIndex].months} Months</p>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Status</label>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                    <p className="text-sm font-bold text-emerald-600">Active Tier</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 flex justify-center">
              <button 
                onClick={() => setShowViewModal(false)}
                className="px-8 py-3 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-sm font-bold shadow-md transition-colors"
              >
                Close View
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Tier Modal */}
      {showEditModal && selectedTierIndex !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl p-8 max-w-2xl w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-2xl font-bold">Edit Tier Configuration</h3>
              <button 
                onClick={() => setShowEditModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-colors"
              >
                <Plus className="rotate-45" size={20} />
              </button>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Tier Name</label>
                  <input 
                    type="text" 
                    value={editingTier?.name || ''}
                    onChange={(e) => setEditingTier({...editingTier, name: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#009688] outline-none transition-all font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Sub-Name / Label</label>
                  <input 
                    type="text" 
                    value={editingTier?.subName || ''}
                    onChange={(e) => setEditingTier({...editingTier, subName: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#009688] outline-none transition-all font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Description</label>
                <textarea 
                  rows={3}
                  value={editingTier?.description || ''}
                  onChange={(e) => setEditingTier({...editingTier, description: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#009688] outline-none transition-all font-medium resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Modules Covered</label>
                <div className="grid grid-cols-3 gap-4">
                  {["Demographics", "Diagnostics", "Resource Planning", "Staff Analytics", "Patient Flow", "Inventory", "Billing", "Claims", "Forecasting", "Compliance", "Quality Metrics", "AI Insights"].map((module) => {
                    const isSelected = editingModules.includes(module.toUpperCase());
                    return (
                      <label 
                        key={module} 
                        className={`flex items-center gap-3 p-3 rounded-xl border transition-all cursor-pointer group ${
                          isSelected 
                            ? "bg-[#E0F2F1] border-[#B2E8D9]" 
                            : "bg-slate-50 border-slate-100 hover:bg-slate-100"
                        }`}
                      >
                        <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${
                          isSelected ? "bg-[#009688] border-[#009688]" : "bg-white border-slate-300"
                        }`}>
                          {isSelected && <Check size={12} className="text-white" strokeWidth={3} />}
                        </div>
                        <input 
                          type="checkbox" 
                          className="hidden"
                          checked={isSelected}
                          onChange={() => {
                            const modUpper = module.toUpperCase();
                            setEditingModules(prev => 
                              prev.includes(modUpper) 
                                ? prev.filter(m => m !== modUpper) 
                                : [...prev, modUpper]
                            );
                          }}
                        />
                        <span className={`text-xs font-bold transition-colors ${
                          isSelected ? "text-[#00796B]" : "text-slate-600"
                        }`}>
                          {module}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Data Limit (Years)</label>
                  <input 
                    type="number" 
                    value={editingTier?.years || 0}
                    onChange={(e) => setEditingTier({...editingTier, years: parseInt(e.target.value) || 0})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#009688] outline-none transition-all font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Data Limit (Months)</label>
                  <input 
                    type="number" 
                    value={editingTier?.months || 0}
                    onChange={(e) => setEditingTier({...editingTier, months: parseInt(e.target.value) || 0})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#009688] outline-none transition-all font-medium"
                  />
                </div>
              </div>
            </div>

            <div className="mt-10 flex gap-4">
              <button 
                onClick={() => setShowEditModal(false)}
                className="flex-1 py-3 border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Cancel Changes
              </button>
              <button 
                onClick={() => {
                  if (selectedTierIndex !== null && editingTier) {
                    const updatedTiers = [...tiers];
                    updatedTiers[selectedTierIndex] = {
                      ...editingTier,
                      modules: editingModules
                    };
                    setTiers(updatedTiers);
                  }
                  setShowEditModal(false);
                  setShowSuccessModal(true);
                }}
                className="flex-1 py-3 bg-[#009688] hover:bg-[#00796B] text-white rounded-xl text-sm font-bold shadow-md transition-colors"
              >
                Update Configuration
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
